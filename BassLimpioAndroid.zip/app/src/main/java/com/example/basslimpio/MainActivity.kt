package com.example.basslimpio

import android.app.Activity
import android.content.Intent
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var player: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private lateinit var status: TextView
    private lateinit var playButton: Button
    private val bands = listOf("Graves 60 Hz", "Bajos 230 Hz", "Medios 910 Hz", "Presencia 3.6 kHz", "Agudos 14 kHz")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.setBackgroundColor(0xFF07111B.toInt())
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 24)
        }
        fun label(text: String, size: Float = 16f): TextView = TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(0xFFF3F7FA.toInt())
            setPadding(0, 8, 0, 8)
        }

        root.addView(label("BASS LIMPIO", 28f))
        root.addView(label("Ecualizador • bajos profundos sin perder claridad"))
        status = label("Abre una canción de audio para empezar.")
        root.addView(status)

        val open = Button(this).apply {
            text = "Elegir canción"
            setOnClickListener {
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "audio/*"
                }
                startActivityForResult(intent, 101)
            }
        }
        root.addView(open, matchWrap())

        playButton = Button(this).apply {
            text = "Reproducir"
            isEnabled = false
            setOnClickListener {
                val p = player ?: return@setOnClickListener
                if (p.isPlaying) {
                    p.pause()
                    text = "Reproducir"
                } else {
                    p.start()
                    text = "Pausar"
                }
            }
        }
        root.addView(playButton, matchWrap())

        root.addView(label("Refuerzo de bajos"))
        val bassLabel = label("40% — potencia controlada")
        root.addView(bassLabel)
        val bassSlider = SeekBar(this).apply {
            max = 100
            progress = 40
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    bassLabel.text = "$progress% — potencia controlada"
                    try {
                        val strength = (progress * 10).coerceIn(0, 1000)
                        bassBoost?.setStrength(strength.toShort())
                    } catch (_: Exception) {}
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        root.addView(bassSlider, matchWrap())

        root.addView(label("Ecualizador de 5 bandas"))
        root.addView(label("Perfil sugerido: graves suaves, medios claros y agudos moderados.", 13f))
        bands.forEachIndexed { index, bandName ->
            val value = label("$bandName: 0 dB")
            root.addView(value)
            val slider = SeekBar(this).apply {
                max = 240
                progress = if (index == 0) 142 else if (index == 1) 132 else if (index == 2) 120 else if (index == 3) 124 else 126
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                        val db = (progress - 120) / 10
                        value.text = "$bandName: ${if (db > 0) "+" else ""}$db dB"
                        try {
                            val eq = equalizer ?: return
                            if (index < eq.numberOfBands) {
                                val range = eq.getBandLevelRange()
                                val millibels = (progress - 120) * 100
                                eq.setBandLevel(index.toShort(), millibels.coerceIn(range[0].toInt(), range[1].toInt()).toShort())
                            }
                        } catch (_: Exception) {}
                    }
                    override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                    override fun onStopTrackingTouch(seekBar: SeekBar?) {}
                })
            }
            root.addView(slider, matchWrap())
        }

        val reset = Button(this).apply {
            text = "Restablecer controles"
            setOnClickListener {
                bassSlider.progress = 40
                Toast.makeText(this@MainActivity, "Ajusta las bandas después de abrir una canción.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(reset, matchWrap())
        root.addView(label("Consejo: si el sonido distorsiona, baja el refuerzo de bajos y el volumen.", 13f))
        setContentView(root)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { bottomMargin = 6 }

    @Deprecated("Legacy document picker callback for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != 101 || resultCode != Activity.RESULT_OK) return
        val uri: Uri = data?.data ?: return
        try {
            player?.release()
            releaseEffects()
            player = MediaPlayer().apply {
                setDataSource(this@MainActivity, uri)
                setOnPreparedListener { mp ->
                    try {
                        equalizer = Equalizer(0, mp.audioSessionId).apply { enabled = true }
                        bassBoost = BassBoost(0, mp.audioSessionId).apply { enabled = true; setStrength(400) }
                        status.text = "Canción lista. Los efectos se aplican a la música reproducida aquí."
                        playButton.isEnabled = true
                    } catch (e: Exception) {
                        status.text = "Canción lista, pero este teléfono no permite activar todos los efectos."
                        playButton.isEnabled = true
                    }
                }
                setOnCompletionListener { playButton.text = "Reproducir" }
                prepareAsync()
            }
            status.text = "Cargando canción…"
            playButton.isEnabled = false
            playButton.text = "Reproducir"
        } catch (e: Exception) {
            status.text = "No se pudo abrir el archivo. Prueba con un MP3 o M4A local."
            Toast.makeText(this, "Error al abrir el audio", Toast.LENGTH_LONG).show()
        }
    }

    private fun releaseEffects() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        equalizer = null
        bassBoost = null
    }

    override fun onDestroy() {
        releaseEffects()
        try { player?.release() } catch (_: Exception) {}
        player = null
        super.onDestroy()
    }
}
